import matplotlib.pyplot as plt

def get_color(pm10):
    if pm10 <= 30:
        return 'green'
    elif pm10 <= 80:
        return 'orange'
    elif pm10 <= 150:
        return 'red'
    else:
        return 'white'

def plot_dust_graph(data_list, location):
    stations = [s for s, _ in data_list]
    pm10_values = [int(v) if v.isdigit() else 0 for _, v in data_list]

    plt.figure(figsize=(10, 6))
    plt.bar(stations, pm10_values, color='skyblue')
    plt.xlabel("측정소")
    plt.ylabel("PM10 농도 (㎍/㎥)")
    plt.title(f"{location} 지역 측정소별 PM10 농도")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.show()
